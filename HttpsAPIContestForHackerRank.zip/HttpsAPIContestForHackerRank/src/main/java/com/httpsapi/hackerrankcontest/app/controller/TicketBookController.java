package com.httpsapi.hackerrankcontest.app.controller;

import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

// http://localhost:8080/api/tickets/ticket/1
// http://localhost:8080/api/tickets/create
//http://localhost:8080/api/tickets/ticket/alltickets
//http://localhost:8080/api/tickets/ticket/1/pri@gamil.com
//http://localhost:8080/api/tickets/ticket/1


@RestController
@RequestMapping(value = "/api/tickets")
public class TicketBookController {


}
